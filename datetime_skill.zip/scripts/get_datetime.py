import datetime

def get_current_datetime():
    """Returns the current date and time as a formatted string."""
    now = datetime.datetime.now()
    return now.strftime("%Y-%m-%d %H:%M:%S")

if __name__ == "__main__":
    print(get_current_datetime())
