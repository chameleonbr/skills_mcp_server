---
name: datetime_skill
description: A simple skill to get the current date and time using a Python script.
---

# Datetime Skill

This skill provides a simple Python script to retrieve the current date and local time.

## Usage

To get the current date and time, run the following Python script:

```bash
python scripts/get_datetime.py
```

## Available Scripts

- **`scripts/get_datetime.py`**: A Python script that prints the current date and time in the format `YYYY-MM-DD HH:MM:SS`.
